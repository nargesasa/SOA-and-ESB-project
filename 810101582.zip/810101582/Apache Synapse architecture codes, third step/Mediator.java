public interface Mediator {
    void mediate(MessageContext context);
}
